create database if not exists test;
use test;
create table if not exists  brands
(
    brand_id          tinyint unsigned auto_increment
        primary key,
    brand_name        varchar(50) not null,
    brand_keyword     text        not null,
    brand_description text        not null,
    created_at        timestamp   null,
    updated_at        timestamp   null
)
    collate = utf8mb4_unicode_ci;

create table if not exists   categorys
(
    category_id          tinyint unsigned auto_increment
        primary key,
    category_name        varchar(50) not null,
    category_keyword     text        not null,
    category_description text        not null,
    created_at           timestamp   null,
    updated_at           timestamp   null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  citys
(
    city_id   int          not null
        primary key,
    city_name varchar(100) not null,
    city_type varchar(50)  not null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  coupons
(
    coupon_id     bigint unsigned auto_increment
        primary key,
    coupon_name   varchar(50)  not null,
    coupon_code   varchar(50)  not null,
    coupon_value  int          not null,
    coupon_status int          not null,
    coupon_expiry date         not null,
    user_id       varchar(255) null,
    created_at    timestamp    null,
    updated_at    timestamp    null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  districts
(
    district_id   int          not null
        primary key,
    district_name varchar(100) not null,
    district_type varchar(50)  not null,
    city_id       int          not null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  images
(
    image_id   bigint unsigned auto_increment
        primary key,
    product_id int       not null,
    image_name text      not null,
    created_at timestamp null,
    updated_at timestamp null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  migrations
(
    id        int unsigned auto_increment
        primary key,
    migration varchar(255) not null,
    batch     int          not null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  products
(
    product_id          int auto_increment
        primary key,
    product_name        varchar(50)      not null,
    category_id         tinyint unsigned null,
    brand_id            tinyint unsigned null,
    product_image       text             not null,
    product_price_buy   int              not null,
    product_price_sell  int              not null,
    product_amount      int              not null,
    product_sale        int              not null,
    product_attribute   text             not null,
    product_detail      text             not null,
    product_keyword     text             not null,
    product_description text             not null,
    product_gender      varchar(100)     null,
    constraint products_brand_id_foreign
        foreign key (brand_id) references brands (brand_id)
            on delete set null,
    constraint products_category_id_foreign
        foreign key (category_id) references categorys (category_id)
            on delete set null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  requirement
(
    id                 bigint unsigned auto_increment
        primary key,
    requirement_name   varchar(50)  not null,
    requirement_email  varchar(50)  not null,
    requirement_title  varchar(255) not null,
    requirement_value  text         not null,
    requirement_active int          not null,
    created_at         timestamp    null,
    updated_at         timestamp    null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  ships
(
    ship_id     int unsigned auto_increment
        primary key,
    city_id     int       not null,
    district_id int       not null,
    ship_price  int       not null,
    created_at  timestamp null,
    updated_at  timestamp null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  slide
(
    id          bigint unsigned auto_increment
        primary key,
    slide_title varchar(100) not null,
    image       varchar(255) null,
    target      varchar(255) null,
    active      int          not null,
    type        int          not null,
    created_at  timestamp    null,
    updated_at  timestamp    null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  users
(
    user_id       int auto_increment
        primary key,
    user_name     varchar(20)  not null,
    user_email    varchar(30)  null,
    password      varchar(255) null,
    user_phone    varchar(10)  null,
    user_addres   varchar(255) null,
    user_district int          null,
    user_city     int          null,
    provider      varchar(255) null,
    provider_id   varchar(255) null,
    role_id       int          not null,
    created_at    timestamp    null,
    updated_at    timestamp    null,
    token         varchar(100) null,
    constraint users_user_email_unique
        unique (user_email)
)
    collate = utf8mb4_unicode_ci;

create table if not exists  comments
(
    comment_id       bigint unsigned auto_increment
        primary key,
    user_id          int          null,
    product_id       int          null,
    comment_customer varchar(255) null,
    comment_admin    varchar(255) null,
    comment_rating   int          null,
    comment_status   int          not null,
    created_at       timestamp    null,
    updated_at       timestamp    null,
    constraint comments_product_id_foreign
        foreign key (product_id) references products (product_id)
            on delete cascade,
    constraint comments_user_id_foreign
        foreign key (user_id) references users (user_id)
            on delete cascade
)
    collate = utf8mb4_unicode_ci;

create table if not exists  orders
(
    order_id       bigint unsigned auto_increment
        primary key,
    user_id        int          null,
    order_shipping text         not null,
    order_note     varchar(255) null,
    order_pay_type int          not null,
    order_profit   int          not null,
    order_total    int          not null,
    order_status   int          not null,
    created_at     timestamp    null,
    updated_at     timestamp    null,
    constraint orders_user_id_foreign
        foreign key (user_id) references users (user_id)
            on delete set null
)
    collate = utf8mb4_unicode_ci;

create table if not exists  orderdetail
(
    order_detail_id       bigint unsigned auto_increment
        primary key,
    order_id              bigint unsigned null,
    product_id            int             null,
    order_detail_quantity int             not null,
    order_detail_price    int             not null,
    created_at            timestamp       null,
    updated_at            timestamp       null,
    constraint orderdetail_order_id_foreign
        foreign key (order_id) references orders (order_id)
            on delete cascade,
    constraint orderdetail_product_id_foreign
        foreign key (product_id) references products (product_id)
            on delete cascade
)
    collate = utf8mb4_unicode_ci;

create table if not exists  posts
(
    id           bigint unsigned auto_increment
        primary key,
    user_id      int          not null,
    post_title   varchar(255) not null,
    post_content text         not null,
    post_image   varchar(255) not null,
    created_at   timestamp    null,
    updated_at   timestamp    null,
    constraint posts_user_id_foreign
        foreign key (user_id) references users (user_id)
            on delete cascade
)
    collate = utf8mb4_unicode_ci;

create  table if not exists wishlist
(
    wishlist_id bigint unsigned auto_increment
        primary key,
    product_id  int not null,
    user_id     int not null,
    constraint wishlist_product_id_foreign
        foreign key (product_id) references products (product_id)
            on delete cascade,
    constraint wishlist_user_id_foreign
        foreign key (user_id) references users (user_id)
            on delete cascade
)
    collate = utf8mb4_unicode_ci;


INSERT INTO categorys (category_id, category_name, category_keyword, category_description, created_at, updated_at) VALUES (5, 'Kính áp tròng', 'Kính áp tròng', 'Kính áp tròng', '2021-12-19 12:58:37', '2024-03-20 15:26:52');
INSERT INTO categorys (category_id, category_name, category_keyword, category_description, created_at, updated_at) VALUES (6, 'Kính mát', 'Kính mát , kính mát hàng hiệu', 'Kính mát', '2021-12-20 13:01:29', '2024-03-23 06:23:04');

INSERT INTO brands (brand_id, brand_name, brand_keyword, brand_description, created_at, updated_at) VALUES (1, 'RAYBAN', 'RAYBAN', 'RAYBAN', '2021-12-19 12:53:39', '2024-03-20 09:48:00');
INSERT INTO brands (brand_id, brand_name, brand_keyword, brand_description, created_at, updated_at) VALUES (2, 'PRADA', 'PRADA', 'PRADA', '2021-12-19 12:53:53', '2024-03-20 09:45:32');
INSERT INTO brands (brand_id, brand_name, brand_keyword, brand_description, created_at, updated_at) VALUES (3, 'MOLSION', 'MOLSION', 'MOLSION', '2021-12-19 12:54:15', '2024-03-20 08:15:17');
INSERT INTO brands (brand_id, brand_name, brand_keyword, brand_description, created_at, updated_at) VALUES (4, 'BOLON', 'BOLON', 'BOLON', '2024-03-20 15:25:19', '2024-03-20 15:25:19');


INSERT INTO citys (city_id, city_name, city_type) VALUES (1, 'Thành phố Hà Nội', 'Thành phố Trung ương');
INSERT INTO citys (city_id, city_name, city_type) VALUES (2, 'Tỉnh Hà Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (4, 'Tỉnh Cao Bằng', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (6, 'Tỉnh Bắc Kạn', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (8, 'Tỉnh Tuyên Quang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (10, 'Tỉnh Lào Cai', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (11, 'Tỉnh Điện Biên', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (12, 'Tỉnh Lai Châu', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (14, 'Tỉnh Sơn La', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (15, 'Tỉnh Yên Bái', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (17, 'Tỉnh Hoà Bình', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (19, 'Tỉnh Thái Nguyên', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (20, 'Tỉnh Lạng Sơn', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (22, 'Tỉnh Quảng Ninh', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (24, 'Tỉnh Bắc Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (25, 'Tỉnh Phú Thọ', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (26, 'Tỉnh Vĩnh Phúc', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (27, 'Tỉnh Bắc Ninh', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (30, 'Tỉnh Hải Dương', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (31, 'Thành phố Hải Phòng', 'Thành phố Trung ương');
INSERT INTO citys (city_id, city_name, city_type) VALUES (33, 'Tỉnh Hưng Yên', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (34, 'Tỉnh Thái Bình', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (35, 'Tỉnh Hà Nam', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (36, 'Tỉnh Nam Định', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (37, 'Tỉnh Ninh Bình', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (38, 'Tỉnh Thanh Hóa', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (40, 'Tỉnh Nghệ An', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (42, 'Tỉnh Hà Tĩnh', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (44, 'Tỉnh Quảng Bình', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (45, 'Tỉnh Quảng Trị', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (46, 'Tỉnh Thừa Thiên Huế', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (48, 'Thành phố Đà Nẵng', 'Thành phố Trung ương');
INSERT INTO citys (city_id, city_name, city_type) VALUES (49, 'Tỉnh Quảng Nam', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (51, 'Tỉnh Quảng Ngãi', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (52, 'Tỉnh Bình Định', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (54, 'Tỉnh Phú Yên', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (56, 'Tỉnh Khánh Hòa', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (58, 'Tỉnh Ninh Thuận', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (60, 'Tỉnh Bình Thuận', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (62, 'Tỉnh Kon Tum', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (64, 'Tỉnh Gia Lai', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (66, 'Tỉnh Đắk Lắk', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (67, 'Tỉnh Đắk Nông', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (68, 'Tỉnh Lâm Đồng', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (70, 'Tỉnh Bình Phước', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (72, 'Tỉnh Tây Ninh', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (74, 'Tỉnh Bình Dương', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (75, 'Tỉnh Đồng Nai', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (77, 'Tỉnh Bà Rịa - Vũng Tàu', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (79, 'Thành phố Hồ Chí Minh', 'Thành phố Trung ương');
INSERT INTO citys (city_id, city_name, city_type) VALUES (80, 'Tỉnh Long An', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (82, 'Tỉnh Tiền Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (83, 'Tỉnh Bến Tre', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (84, 'Tỉnh Trà Vinh', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (86, 'Tỉnh Vĩnh Long', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (87, 'Tỉnh Đồng Tháp', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (89, 'Tỉnh An Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (91, 'Tỉnh Kiên Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (92, 'Thành phố Cần Thơ', 'Thành phố Trung ương');
INSERT INTO citys (city_id, city_name, city_type) VALUES (93, 'Tỉnh Hậu Giang', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (94, 'Tỉnh Sóc Trăng', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (95, 'Tỉnh Bạc Liêu', 'Tỉnh');
INSERT INTO citys (city_id, city_name, city_type) VALUES (96, 'Tỉnh Cà Mau', 'Tỉnh');


INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (1, 'Quận Ba Đình', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (2, 'Quận Hoàn Kiếm', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (3, 'Quận Tây Hồ', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (4, 'Quận Long Biên', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (5, 'Quận Cầu Giấy', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (6, 'Quận Đống Đa', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (7, 'Quận Hai Bà Trưng', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (8, 'Quận Hoàng Mai', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (9, 'Quận Thanh Xuân', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (16, 'Huyện Sóc Sơn', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (17, 'Huyện Đông Anh', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (18, 'Huyện Gia Lâm', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (19, 'Quận Nam Từ Liêm', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (20, 'Huyện Thanh Trì', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (21, 'Quận Bắc Từ Liêm', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (24, 'Thành phố Hà Giang', 'Thành phố', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (26, 'Huyện Đồng Văn', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (27, 'Huyện Mèo Vạc', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (28, 'Huyện Yên Minh', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (29, 'Huyện Quản Bạ', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (30, 'Huyện Vị Xuyên', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (31, 'Huyện Bắc Mê', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (32, 'Huyện Hoàng Su Phì', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (33, 'Huyện Xín Mần', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (34, 'Huyện Bắc Quang', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (35, 'Huyện Quang Bình', 'Huyện', 2);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (40, 'Thành phố Cao Bằng', 'Thành phố', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (42, 'Huyện Bảo Lâm', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (43, 'Huyện Bảo Lạc', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (44, 'Huyện Thông Nông', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (45, 'Huyện Hà Quảng', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (46, 'Huyện Trà Lĩnh', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (47, 'Huyện Trùng Khánh', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (48, 'Huyện Hạ Lang', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (49, 'Huyện Quảng Uyên', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (50, 'Huyện Phục Hoà', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (51, 'Huyện Hoà An', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (52, 'Huyện Nguyên Bình', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (53, 'Huyện Thạch An', 'Huyện', 4);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (58, 'Thành Phố Bắc Kạn', 'Thành phố', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (60, 'Huyện Pác Nặm', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (61, 'Huyện Ba Bể', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (62, 'Huyện Ngân Sơn', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (63, 'Huyện Bạch Thông', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (64, 'Huyện Chợ Đồn', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (65, 'Huyện Chợ Mới', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (66, 'Huyện Na Rì', 'Huyện', 6);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (70, 'Thành phố Tuyên Quang', 'Thành phố', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (71, 'Huyện Lâm Bình', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (72, 'Huyện Nà Hang', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (73, 'Huyện Chiêm Hóa', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (74, 'Huyện Hàm Yên', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (75, 'Huyện Yên Sơn', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (76, 'Huyện Sơn Dương', 'Huyện', 8);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (80, 'Thành phố Lào Cai', 'Thành phố', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (82, 'Huyện Bát Xát', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (83, 'Huyện Mường Khương', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (84, 'Huyện Si Ma Cai', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (85, 'Huyện Bắc Hà', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (86, 'Huyện Bảo Thắng', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (87, 'Huyện Bảo Yên', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (88, 'Huyện Sa Pa', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (89, 'Huyện Văn Bàn', 'Huyện', 10);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (94, 'Thành phố Điện Biên Phủ', 'Thành phố', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (95, 'Thị Xã Mường Lay', 'Thị xã', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (96, 'Huyện Mường Nhé', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (97, 'Huyện Mường Chà', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (98, 'Huyện Tủa Chùa', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (99, 'Huyện Tuần Giáo', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (100, 'Huyện Điện Biên', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (101, 'Huyện Điện Biên Đông', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (102, 'Huyện Mường Ảng', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (103, 'Huyện Nậm Pồ', 'Huyện', 11);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (105, 'Thành phố Lai Châu', 'Thành phố', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (106, 'Huyện Tam Đường', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (107, 'Huyện Mường Tè', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (108, 'Huyện Sìn Hồ', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (109, 'Huyện Phong Thổ', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (110, 'Huyện Than Uyên', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (111, 'Huyện Tân Uyên', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (112, 'Huyện Nậm Nhùn', 'Huyện', 12);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (116, 'Thành phố Sơn La', 'Thành phố', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (118, 'Huyện Quỳnh Nhai', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (119, 'Huyện Thuận Châu', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (120, 'Huyện Mường La', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (121, 'Huyện Bắc Yên', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (122, 'Huyện Phù Yên', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (123, 'Huyện Mộc Châu', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (124, 'Huyện Yên Châu', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (125, 'Huyện Mai Sơn', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (126, 'Huyện Sông Mã', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (127, 'Huyện Sốp Cộp', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (128, 'Huyện Vân Hồ', 'Huyện', 14);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (132, 'Thành phố Yên Bái', 'Thành phố', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (133, 'Thị xã Nghĩa Lộ', 'Thị xã', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (135, 'Huyện Lục Yên', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (136, 'Huyện Văn Yên', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (137, 'Huyện Mù Căng Chải', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (138, 'Huyện Trấn Yên', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (139, 'Huyện Trạm Tấu', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (140, 'Huyện Văn Chấn', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (141, 'Huyện Yên Bình', 'Huyện', 15);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (148, 'Thành phố Hòa Bình', 'Thành phố', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (150, 'Huyện Đà Bắc', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (151, 'Huyện Kỳ Sơn', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (152, 'Huyện Lương Sơn', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (153, 'Huyện Kim Bôi', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (154, 'Huyện Cao Phong', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (155, 'Huyện Tân Lạc', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (156, 'Huyện Mai Châu', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (157, 'Huyện Lạc Sơn', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (158, 'Huyện Yên Thủy', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (159, 'Huyện Lạc Thủy', 'Huyện', 17);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (164, 'Thành phố Thái Nguyên', 'Thành phố', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (165, 'Thành phố Sông Công', 'Thành phố', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (167, 'Huyện Định Hóa', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (168, 'Huyện Phú Lương', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (169, 'Huyện Đồng Hỷ', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (170, 'Huyện Võ Nhai', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (171, 'Huyện Đại Từ', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (172, 'Thị xã Phổ Yên', 'Thị xã', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (173, 'Huyện Phú Bình', 'Huyện', 19);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (178, 'Thành phố Lạng Sơn', 'Thành phố', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (180, 'Huyện Tràng Định', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (181, 'Huyện Bình Gia', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (182, 'Huyện Văn Lãng', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (183, 'Huyện Cao Lộc', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (184, 'Huyện Văn Quan', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (185, 'Huyện Bắc Sơn', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (186, 'Huyện Hữu Lũng', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (187, 'Huyện Chi Lăng', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (188, 'Huyện Lộc Bình', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (189, 'Huyện Đình Lập', 'Huyện', 20);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (193, 'Thành phố Hạ Long', 'Thành phố', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (194, 'Thành phố Móng Cái', 'Thành phố', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (195, 'Thành phố Cẩm Phả', 'Thành phố', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (196, 'Thành phố Uông Bí', 'Thành phố', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (198, 'Huyện Bình Liêu', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (199, 'Huyện Tiên Yên', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (200, 'Huyện Đầm Hà', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (201, 'Huyện Hải Hà', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (202, 'Huyện Ba Chẽ', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (203, 'Huyện Vân Đồn', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (204, 'Huyện Hoành Bồ', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (205, 'Thị xã Đông Triều', 'Thị xã', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (206, 'Thị xã Quảng Yên', 'Thị xã', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (207, 'Huyện Cô Tô', 'Huyện', 22);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (213, 'Thành phố Bắc Giang', 'Thành phố', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (215, 'Huyện Yên Thế', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (216, 'Huyện Tân Yên', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (217, 'Huyện Lạng Giang', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (218, 'Huyện Lục Nam', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (219, 'Huyện Lục Ngạn', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (220, 'Huyện Sơn Động', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (221, 'Huyện Yên Dũng', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (222, 'Huyện Việt Yên', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (223, 'Huyện Hiệp Hòa', 'Huyện', 24);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (227, 'Thành phố Việt Trì', 'Thành phố', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (228, 'Thị xã Phú Thọ', 'Thị xã', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (230, 'Huyện Đoan Hùng', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (231, 'Huyện Hạ Hoà', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (232, 'Huyện Thanh Ba', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (233, 'Huyện Phù Ninh', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (234, 'Huyện Yên Lập', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (235, 'Huyện Cẩm Khê', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (236, 'Huyện Tam Nông', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (237, 'Huyện Lâm Thao', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (238, 'Huyện Thanh Sơn', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (239, 'Huyện Thanh Thuỷ', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (240, 'Huyện Tân Sơn', 'Huyện', 25);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (243, 'Thành phố Vĩnh Yên', 'Thành phố', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (244, 'Thị xã Phúc Yên', 'Thị xã', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (246, 'Huyện Lập Thạch', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (247, 'Huyện Tam Dương', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (248, 'Huyện Tam Đảo', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (249, 'Huyện Bình Xuyên', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (250, 'Huyện Mê Linh', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (251, 'Huyện Yên Lạc', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (252, 'Huyện Vĩnh Tường', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (253, 'Huyện Sông Lô', 'Huyện', 26);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (256, 'Thành phố Bắc Ninh', 'Thành phố', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (258, 'Huyện Yên Phong', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (259, 'Huyện Quế Võ', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (260, 'Huyện Tiên Du', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (261, 'Thị xã Từ Sơn', 'Thị xã', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (262, 'Huyện Thuận Thành', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (263, 'Huyện Gia Bình', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (264, 'Huyện Lương Tài', 'Huyện', 27);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (268, 'Quận Hà Đông', 'Quận', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (269, 'Thị xã Sơn Tây', 'Thị xã', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (271, 'Huyện Ba Vì', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (272, 'Huyện Phúc Thọ', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (273, 'Huyện Đan Phượng', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (274, 'Huyện Hoài Đức', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (275, 'Huyện Quốc Oai', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (276, 'Huyện Thạch Thất', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (277, 'Huyện Chương Mỹ', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (278, 'Huyện Thanh Oai', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (279, 'Huyện Thường Tín', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (280, 'Huyện Phú Xuyên', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (281, 'Huyện Ứng Hòa', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (282, 'Huyện Mỹ Đức', 'Huyện', 1);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (288, 'Thành phố Hải Dương', 'Thành phố', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (290, 'Thị xã Chí Linh', 'Thị xã', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (291, 'Huyện Nam Sách', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (292, 'Huyện Kinh Môn', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (293, 'Huyện Kim Thành', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (294, 'Huyện Thanh Hà', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (295, 'Huyện Cẩm Giàng', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (296, 'Huyện Bình Giang', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (297, 'Huyện Gia Lộc', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (298, 'Huyện Tứ Kỳ', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (299, 'Huyện Ninh Giang', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (300, 'Huyện Thanh Miện', 'Huyện', 30);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (303, 'Quận Hồng Bàng', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (304, 'Quận Ngô Quyền', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (305, 'Quận Lê Chân', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (306, 'Quận Hải An', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (307, 'Quận Kiến An', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (308, 'Quận Đồ Sơn', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (309, 'Quận Dương Kinh', 'Quận', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (311, 'Huyện Thuỷ Nguyên', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (312, 'Huyện An Dương', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (313, 'Huyện An Lão', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (314, 'Huyện Kiến Thuỵ', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (315, 'Huyện Tiên Lãng', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (316, 'Huyện Vĩnh Bảo', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (317, 'Huyện Cát Hải', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (318, 'Huyện Bạch Long Vĩ', 'Huyện', 31);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (323, 'Thành phố Hưng Yên', 'Thành phố', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (325, 'Huyện Văn Lâm', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (326, 'Huyện Văn Giang', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (327, 'Huyện Yên Mỹ', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (328, 'Huyện Mỹ Hào', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (329, 'Huyện Ân Thi', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (330, 'Huyện Khoái Châu', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (331, 'Huyện Kim Động', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (332, 'Huyện Tiên Lữ', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (333, 'Huyện Phù Cừ', 'Huyện', 33);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (336, 'Thành phố Thái Bình', 'Thành phố', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (338, 'Huyện Quỳnh Phụ', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (339, 'Huyện Hưng Hà', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (340, 'Huyện Đông Hưng', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (341, 'Huyện Thái Thụy', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (342, 'Huyện Tiền Hải', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (343, 'Huyện Kiến Xương', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (344, 'Huyện Vũ Thư', 'Huyện', 34);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (347, 'Thành phố Phủ Lý', 'Thành phố', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (349, 'Huyện Duy Tiên', 'Huyện', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (350, 'Huyện Kim Bảng', 'Huyện', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (351, 'Huyện Thanh Liêm', 'Huyện', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (352, 'Huyện Bình Lục', 'Huyện', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (353, 'Huyện Lý Nhân', 'Huyện', 35);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (356, 'Thành phố Nam Định', 'Thành phố', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (358, 'Huyện Mỹ Lộc', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (359, 'Huyện Vụ Bản', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (360, 'Huyện Ý Yên', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (361, 'Huyện Nghĩa Hưng', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (362, 'Huyện Nam Trực', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (363, 'Huyện Trực Ninh', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (364, 'Huyện Xuân Trường', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (365, 'Huyện Giao Thủy', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (366, 'Huyện Hải Hậu', 'Huyện', 36);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (369, 'Thành phố Ninh Bình', 'Thành phố', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (370, 'Thành phố Tam Điệp', 'Thành phố', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (372, 'Huyện Nho Quan', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (373, 'Huyện Gia Viễn', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (374, 'Huyện Hoa Lư', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (375, 'Huyện Yên Khánh', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (376, 'Huyện Kim Sơn', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (377, 'Huyện Yên Mô', 'Huyện', 37);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (380, 'Thành phố Thanh Hóa', 'Thành phố', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (381, 'Thị xã Bỉm Sơn', 'Thị xã', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (382, 'Thị xã Sầm Sơn', 'Thị xã', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (384, 'Huyện Mường Lát', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (385, 'Huyện Quan Hóa', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (386, 'Huyện Bá Thước', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (387, 'Huyện Quan Sơn', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (388, 'Huyện Lang Chánh', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (389, 'Huyện Ngọc Lặc', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (390, 'Huyện Cẩm Thủy', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (391, 'Huyện Thạch Thành', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (392, 'Huyện Hà Trung', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (393, 'Huyện Vĩnh Lộc', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (394, 'Huyện Yên Định', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (395, 'Huyện Thọ Xuân', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (396, 'Huyện Thường Xuân', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (397, 'Huyện Triệu Sơn', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (398, 'Huyện Thiệu Hóa', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (399, 'Huyện Hoằng Hóa', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (400, 'Huyện Hậu Lộc', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (401, 'Huyện Nga Sơn', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (402, 'Huyện Như Xuân', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (403, 'Huyện Như Thanh', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (404, 'Huyện Nông Cống', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (405, 'Huyện Đông Sơn', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (406, 'Huyện Quảng Xương', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (407, 'Huyện Tĩnh Gia', 'Huyện', 38);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (412, 'Thành phố Vinh', 'Thành phố', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (413, 'Thị xã Cửa Lò', 'Thị xã', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (414, 'Thị xã Thái Hoà', 'Thị xã', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (415, 'Huyện Quế Phong', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (416, 'Huyện Quỳ Châu', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (417, 'Huyện Kỳ Sơn', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (418, 'Huyện Tương Dương', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (419, 'Huyện Nghĩa Đàn', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (420, 'Huyện Quỳ Hợp', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (421, 'Huyện Quỳnh Lưu', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (422, 'Huyện Con Cuông', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (423, 'Huyện Tân Kỳ', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (424, 'Huyện Anh Sơn', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (425, 'Huyện Diễn Châu', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (426, 'Huyện Yên Thành', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (427, 'Huyện Đô Lương', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (428, 'Huyện Thanh Chương', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (429, 'Huyện Nghi Lộc', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (430, 'Huyện Nam Đàn', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (431, 'Huyện Hưng Nguyên', 'Huyện', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (432, 'Thị xã Hoàng Mai', 'Thị xã', 40);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (436, 'Thành phố Hà Tĩnh', 'Thành phố', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (437, 'Thị xã Hồng Lĩnh', 'Thị xã', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (439, 'Huyện Hương Sơn', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (440, 'Huyện Đức Thọ', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (441, 'Huyện Vũ Quang', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (442, 'Huyện Nghi Xuân', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (443, 'Huyện Can Lộc', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (444, 'Huyện Hương Khê', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (445, 'Huyện Thạch Hà', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (446, 'Huyện Cẩm Xuyên', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (447, 'Huyện Kỳ Anh', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (448, 'Huyện Lộc Hà', 'Huyện', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (449, 'Thị xã Kỳ Anh', 'Thị xã', 42);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (450, 'Thành Phố Đồng Hới', 'Thành phố', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (452, 'Huyện Minh Hóa', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (453, 'Huyện Tuyên Hóa', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (454, 'Huyện Quảng Trạch', 'Thị xã', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (455, 'Huyện Bố Trạch', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (456, 'Huyện Quảng Ninh', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (457, 'Huyện Lệ Thủy', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (458, 'Thị xã Ba Đồn', 'Huyện', 44);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (461, 'Thành phố Đông Hà', 'Thành phố', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (462, 'Thị xã Quảng Trị', 'Thị xã', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (464, 'Huyện Vĩnh Linh', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (465, 'Huyện Hướng Hóa', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (466, 'Huyện Gio Linh', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (467, 'Huyện Đa Krông', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (468, 'Huyện Cam Lộ', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (469, 'Huyện Triệu Phong', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (470, 'Huyện Hải Lăng', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (471, 'Huyện Cồn Cỏ', 'Huyện', 45);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (474, 'Thành phố Huế', 'Thành phố', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (476, 'Huyện Phong Điền', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (477, 'Huyện Quảng Điền', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (478, 'Huyện Phú Vang', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (479, 'Thị xã Hương Thủy', 'Thị xã', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (480, 'Thị xã Hương Trà', 'Thị xã', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (481, 'Huyện A Lưới', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (482, 'Huyện Phú Lộc', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (483, 'Huyện Nam Đông', 'Huyện', 46);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (490, 'Quận Liên Chiểu', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (491, 'Quận Thanh Khê', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (492, 'Quận Hải Châu', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (493, 'Quận Sơn Trà', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (494, 'Quận Ngũ Hành Sơn', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (495, 'Quận Cẩm Lệ', 'Quận', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (497, 'Huyện Hòa Vang', 'Huyện', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (498, 'Huyện Hoàng Sa', 'Huyện', 48);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (502, 'Thành phố Tam Kỳ', 'Thành phố', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (503, 'Thành phố Hội An', 'Thành phố', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (504, 'Huyện Tây Giang', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (505, 'Huyện Đông Giang', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (506, 'Huyện Đại Lộc', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (507, 'Thị xã Điện Bàn', 'Thị xã', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (508, 'Huyện Duy Xuyên', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (509, 'Huyện Quế Sơn', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (510, 'Huyện Nam Giang', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (511, 'Huyện Phước Sơn', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (512, 'Huyện Hiệp Đức', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (513, 'Huyện Thăng Bình', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (514, 'Huyện Tiên Phước', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (515, 'Huyện Bắc Trà My', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (516, 'Huyện Nam Trà My', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (517, 'Huyện Núi Thành', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (518, 'Huyện Phú Ninh', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (519, 'Huyện Nông Sơn', 'Huyện', 49);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (522, 'Thành phố Quảng Ngãi', 'Thành phố', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (524, 'Huyện Bình Sơn', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (525, 'Huyện Trà Bồng', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (526, 'Huyện Tây Trà', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (527, 'Huyện Sơn Tịnh', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (528, 'Huyện Tư Nghĩa', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (529, 'Huyện Sơn Hà', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (530, 'Huyện Sơn Tây', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (531, 'Huyện Minh Long', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (532, 'Huyện Nghĩa Hành', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (533, 'Huyện Mộ Đức', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (534, 'Huyện Đức Phổ', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (535, 'Huyện Ba Tơ', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (536, 'Huyện Lý Sơn', 'Huyện', 51);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (540, 'Thành phố Qui Nhơn', 'Thành phố', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (542, 'Huyện An Lão', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (543, 'Huyện Hoài Nhơn', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (544, 'Huyện Hoài Ân', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (545, 'Huyện Phù Mỹ', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (546, 'Huyện Vĩnh Thạnh', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (547, 'Huyện Tây Sơn', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (548, 'Huyện Phù Cát', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (549, 'Thị xã An Nhơn', 'Thị xã', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (550, 'Huyện Tuy Phước', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (551, 'Huyện Vân Canh', 'Huyện', 52);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (555, 'Thành phố Tuy Hoà', 'Thành phố', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (557, 'Thị xã Sông Cầu', 'Thị xã', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (558, 'Huyện Đồng Xuân', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (559, 'Huyện Tuy An', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (560, 'Huyện Sơn Hòa', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (561, 'Huyện Sông Hinh', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (562, 'Huyện Tây Hoà', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (563, 'Huyện Phú Hoà', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (564, 'Huyện Đông Hòa', 'Huyện', 54);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (568, 'Thành phố Nha Trang', 'Thành phố', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (569, 'Thành phố Cam Ranh', 'Thành phố', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (570, 'Huyện Cam Lâm', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (571, 'Huyện Vạn Ninh', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (572, 'Thị xã Ninh Hòa', 'Thị xã', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (573, 'Huyện Khánh Vĩnh', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (574, 'Huyện Diên Khánh', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (575, 'Huyện Khánh Sơn', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (576, 'Huyện Trường Sa', 'Huyện', 56);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (582, 'Thành phố Phan Rang-Tháp Chàm', 'Thành phố', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (584, 'Huyện Bác Ái', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (585, 'Huyện Ninh Sơn', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (586, 'Huyện Ninh Hải', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (587, 'Huyện Ninh Phước', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (588, 'Huyện Thuận Bắc', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (589, 'Huyện Thuận Nam', 'Huyện', 58);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (593, 'Thành phố Phan Thiết', 'Thành phố', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (594, 'Thị xã La Gi', 'Thị xã', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (595, 'Huyện Tuy Phong', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (596, 'Huyện Bắc Bình', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (597, 'Huyện Hàm Thuận Bắc', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (598, 'Huyện Hàm Thuận Nam', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (599, 'Huyện Tánh Linh', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (600, 'Huyện Đức Linh', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (601, 'Huyện Hàm Tân', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (602, 'Huyện Phú Quí', 'Huyện', 60);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (608, 'Thành phố Kon Tum', 'Thành phố', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (610, 'Huyện Đắk Glei', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (611, 'Huyện Ngọc Hồi', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (612, 'Huyện Đắk Tô', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (613, 'Huyện Kon Plông', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (614, 'Huyện Kon Rẫy', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (615, 'Huyện Đắk Hà', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (616, 'Huyện Sa Thầy', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (617, 'Huyện Tu Mơ Rông', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (618, 'Huyện Ia H\' Drai', 'Huyện', 62);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (622, 'Thành phố Pleiku', 'Thành phố', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (623, 'Thị xã An Khê', 'Thị xã', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (624, 'Thị xã Ayun Pa', 'Thị xã', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (625, 'Huyện KBang', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (626, 'Huyện Đăk Đoa', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (627, 'Huyện Chư Păh', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (628, 'Huyện Ia Grai', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (629, 'Huyện Mang Yang', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (630, 'Huyện Kông Chro', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (631, 'Huyện Đức Cơ', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (632, 'Huyện Chư Prông', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (633, 'Huyện Chư Sê', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (634, 'Huyện Đăk Pơ', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (635, 'Huyện Ia Pa', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (637, 'Huyện Krông Pa', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (638, 'Huyện Phú Thiện', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (639, 'Huyện Chư Pưh', 'Huyện', 64);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (643, 'Thành phố Buôn Ma Thuột', 'Thành phố', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (644, 'Thị Xã Buôn Hồ', 'Thị xã', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (645, 'Huyện Ea H\'leo', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (646, 'Huyện Ea Súp', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (647, 'Huyện Buôn Đôn', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (648, 'Huyện Cư M\'gar', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (649, 'Huyện Krông Búk', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (650, 'Huyện Krông Năng', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (651, 'Huyện Ea Kar', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (652, 'Huyện M\'Đrắk', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (653, 'Huyện Krông Bông', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (654, 'Huyện Krông Pắc', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (655, 'Huyện Krông A Na', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (656, 'Huyện Lắk', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (657, 'Huyện Cư Kuin', 'Huyện', 66);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (660, 'Thị xã Gia Nghĩa', 'Thị xã', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (661, 'Huyện Đăk Glong', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (662, 'Huyện Cư Jút', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (663, 'Huyện Đắk Mil', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (664, 'Huyện Krông Nô', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (665, 'Huyện Đắk Song', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (666, 'Huyện Đắk R\'Lấp', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (667, 'Huyện Tuy Đức', 'Huyện', 67);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (672, 'Thành phố Đà Lạt', 'Thành phố', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (673, 'Thành phố Bảo Lộc', 'Thành phố', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (674, 'Huyện Đam Rông', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (675, 'Huyện Lạc Dương', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (676, 'Huyện Lâm Hà', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (677, 'Huyện Đơn Dương', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (678, 'Huyện Đức Trọng', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (679, 'Huyện Di Linh', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (680, 'Huyện Bảo Lâm', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (681, 'Huyện Đạ Huoai', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (682, 'Huyện Đạ Tẻh', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (683, 'Huyện Cát Tiên', 'Huyện', 68);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (688, 'Thị xã Phước Long', 'Thị xã', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (689, 'Thị xã Đồng Xoài', 'Thị xã', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (690, 'Thị xã Bình Long', 'Thị xã', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (691, 'Huyện Bù Gia Mập', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (692, 'Huyện Lộc Ninh', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (693, 'Huyện Bù Đốp', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (694, 'Huyện Hớn Quản', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (695, 'Huyện Đồng Phú', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (696, 'Huyện Bù Đăng', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (697, 'Huyện Chơn Thành', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (698, 'Huyện Phú Riềng', 'Huyện', 70);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (703, 'Thành phố Tây Ninh', 'Thành phố', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (705, 'Huyện Tân Biên', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (706, 'Huyện Tân Châu', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (707, 'Huyện Dương Minh Châu', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (708, 'Huyện Châu Thành', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (709, 'Huyện Hòa Thành', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (710, 'Huyện Gò Dầu', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (711, 'Huyện Bến Cầu', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (712, 'Huyện Trảng Bàng', 'Huyện', 72);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (718, 'Thành phố Thủ Dầu Một', 'Thành phố', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (719, 'Huyện Bàu Bàng', 'Huyện', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (720, 'Huyện Dầu Tiếng', 'Huyện', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (721, 'Thị xã Bến Cát', 'Thị xã', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (722, 'Huyện Phú Giáo', 'Huyện', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (723, 'Thị xã Tân Uyên', 'Thị xã', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (724, 'Thị xã Dĩ An', 'Thị xã', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (725, 'Thị xã Thuận An', 'Thị xã', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (726, 'Huyện Bắc Tân Uyên', 'Huyện', 74);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (731, 'Thành phố Biên Hòa', 'Thành phố', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (732, 'Thị xã Long Khánh', 'Thị xã', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (734, 'Huyện Tân Phú', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (735, 'Huyện Vĩnh Cửu', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (736, 'Huyện Định Quán', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (737, 'Huyện Trảng Bom', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (738, 'Huyện Thống Nhất', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (739, 'Huyện Cẩm Mỹ', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (740, 'Huyện Long Thành', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (741, 'Huyện Xuân Lộc', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (742, 'Huyện Nhơn Trạch', 'Huyện', 75);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (747, 'Thành phố Vũng Tàu', 'Thành phố', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (748, 'Thành phố Bà Rịa', 'Thành phố', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (750, 'Huyện Châu Đức', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (751, 'Huyện Xuyên Mộc', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (752, 'Huyện Long Điền', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (753, 'Huyện Đất Đỏ', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (754, 'Huyện Tân Thành', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (755, 'Huyện Côn Đảo', 'Huyện', 77);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (760, 'Quận 1', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (761, 'Quận 12', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (762, 'Quận Thủ Đức', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (763, 'Quận 9', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (764, 'Quận Gò Vấp', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (765, 'Quận Bình Thạnh', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (766, 'Quận Tân Bình', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (767, 'Quận Tân Phú', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (768, 'Quận Phú Nhuận', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (769, 'Quận 2', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (770, 'Quận 3', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (771, 'Quận 10', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (772, 'Quận 11', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (773, 'Quận 4', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (774, 'Quận 5', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (775, 'Quận 6', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (776, 'Quận 8', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (777, 'Quận Bình Tân', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (778, 'Quận 7', 'Quận', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (783, 'Huyện Củ Chi', 'Huyện', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (784, 'Huyện Hóc Môn', 'Huyện', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (785, 'Huyện Bình Chánh', 'Huyện', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (786, 'Huyện Nhà Bè', 'Huyện', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (787, 'Huyện Cần Giờ', 'Huyện', 79);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (794, 'Thành phố Tân An', 'Thành phố', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (795, 'Thị xã Kiến Tường', 'Thị xã', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (796, 'Huyện Tân Hưng', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (797, 'Huyện Vĩnh Hưng', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (798, 'Huyện Mộc Hóa', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (799, 'Huyện Tân Thạnh', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (800, 'Huyện Thạnh Hóa', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (801, 'Huyện Đức Huệ', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (802, 'Huyện Đức Hòa', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (803, 'Huyện Bến Lức', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (804, 'Huyện Thủ Thừa', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (805, 'Huyện Tân Trụ', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (806, 'Huyện Cần Đước', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (807, 'Huyện Cần Giuộc', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (808, 'Huyện Châu Thành', 'Huyện', 80);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (815, 'Thành phố Mỹ Tho', 'Thành phố', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (816, 'Thị xã Gò Công', 'Thị xã', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (817, 'Thị xã Cai Lậy', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (818, 'Huyện Tân Phước', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (819, 'Huyện Cái Bè', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (820, 'Huyện Cai Lậy', 'Thị xã', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (821, 'Huyện Châu Thành', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (822, 'Huyện Chợ Gạo', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (823, 'Huyện Gò Công Tây', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (824, 'Huyện Gò Công Đông', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (825, 'Huyện Tân Phú Đông', 'Huyện', 82);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (829, 'Thành phố Bến Tre', 'Thành phố', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (831, 'Huyện Châu Thành', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (832, 'Huyện Chợ Lách', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (833, 'Huyện Mỏ Cày Nam', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (834, 'Huyện Giồng Trôm', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (835, 'Huyện Bình Đại', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (836, 'Huyện Ba Tri', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (837, 'Huyện Thạnh Phú', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (838, 'Huyện Mỏ Cày Bắc', 'Huyện', 83);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (842, 'Thành phố Trà Vinh', 'Thành phố', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (844, 'Huyện Càng Long', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (845, 'Huyện Cầu Kè', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (846, 'Huyện Tiểu Cần', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (847, 'Huyện Châu Thành', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (848, 'Huyện Cầu Ngang', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (849, 'Huyện Trà Cú', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (850, 'Huyện Duyên Hải', 'Huyện', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (851, 'Thị xã Duyên Hải', 'Thị xã', 84);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (855, 'Thành phố Vĩnh Long', 'Thành phố', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (857, 'Huyện Long Hồ', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (858, 'Huyện Mang Thít', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (859, 'Huyện  Vũng Liêm', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (860, 'Huyện Tam Bình', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (861, 'Thị xã Bình Minh', 'Thị xã', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (862, 'Huyện Trà Ôn', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (863, 'Huyện Bình Tân', 'Huyện', 86);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (866, 'Thành phố Cao Lãnh', 'Thành phố', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (867, 'Thành phố Sa Đéc', 'Thành phố', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (868, 'Thị xã Hồng Ngự', 'Thị xã', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (869, 'Huyện Tân Hồng', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (870, 'Huyện Hồng Ngự', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (871, 'Huyện Tam Nông', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (872, 'Huyện Tháp Mười', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (873, 'Huyện Cao Lãnh', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (874, 'Huyện Thanh Bình', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (875, 'Huyện Lấp Vò', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (876, 'Huyện Lai Vung', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (877, 'Huyện Châu Thành', 'Huyện', 87);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (883, 'Thành phố Long Xuyên', 'Thành phố', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (884, 'Thành phố Châu Đốc', 'Thành phố', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (886, 'Huyện An Phú', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (887, 'Thị xã Tân Châu', 'Thị xã', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (888, 'Huyện Phú Tân', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (889, 'Huyện Châu Phú', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (890, 'Huyện Tịnh Biên', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (891, 'Huyện Tri Tôn', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (892, 'Huyện Châu Thành', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (893, 'Huyện Chợ Mới', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (894, 'Huyện Thoại Sơn', 'Huyện', 89);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (899, 'Thành phố Rạch Giá', 'Thành phố', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (900, 'Thị xã Hà Tiên', 'Thị xã', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (902, 'Huyện Kiên Lương', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (903, 'Huyện Hòn Đất', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (904, 'Huyện Tân Hiệp', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (905, 'Huyện Châu Thành', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (906, 'Huyện Giồng Riềng', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (907, 'Huyện Gò Quao', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (908, 'Huyện An Biên', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (909, 'Huyện An Minh', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (910, 'Huyện Vĩnh Thuận', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (911, 'Huyện Phú Quốc', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (912, 'Huyện Kiên Hải', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (913, 'Huyện U Minh Thượng', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (914, 'Huyện Giang Thành', 'Huyện', 91);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (916, 'Quận Ninh Kiều', 'Quận', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (917, 'Quận Ô Môn', 'Quận', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (918, 'Quận Bình Thuỷ', 'Quận', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (919, 'Quận Cái Răng', 'Quận', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (923, 'Quận Thốt Nốt', 'Quận', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (924, 'Huyện Vĩnh Thạnh', 'Huyện', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (925, 'Huyện Cờ Đỏ', 'Huyện', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (926, 'Huyện Phong Điền', 'Huyện', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (927, 'Huyện Thới Lai', 'Huyện', 92);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (930, 'Thành phố Vị Thanh', 'Thành phố', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (931, 'Thị xã Ngã Bảy', 'Thị xã', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (932, 'Huyện Châu Thành A', 'Huyện', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (933, 'Huyện Châu Thành', 'Huyện', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (934, 'Huyện Phụng Hiệp', 'Huyện', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (935, 'Huyện Vị Thuỷ', 'Huyện', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (936, 'Huyện Long Mỹ', 'Huyện', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (937, 'Thị xã Long Mỹ', 'Thị xã', 93);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (941, 'Thành phố Sóc Trăng', 'Thành phố', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (942, 'Huyện Châu Thành', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (943, 'Huyện Kế Sách', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (944, 'Huyện Mỹ Tú', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (945, 'Huyện Cù Lao Dung', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (946, 'Huyện Long Phú', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (947, 'Huyện Mỹ Xuyên', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (948, 'Thị xã Ngã Năm', 'Thị xã', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (949, 'Huyện Thạnh Trị', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (950, 'Thị xã Vĩnh Châu', 'Thị xã', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (951, 'Huyện Trần Đề', 'Huyện', 94);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (954, 'Thành phố Bạc Liêu', 'Thành phố', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (956, 'Huyện Hồng Dân', 'Huyện', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (957, 'Huyện Phước Long', 'Huyện', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (958, 'Huyện Vĩnh Lợi', 'Huyện', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (959, 'Thị xã Giá Rai', 'Thị xã', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (960, 'Huyện Đông Hải', 'Huyện', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (961, 'Huyện Hoà Bình', 'Huyện', 95);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (964, 'Thành phố Cà Mau', 'Thành phố', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (966, 'Huyện U Minh', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (967, 'Huyện Thới Bình', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (968, 'Huyện Trần Văn Thời', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (969, 'Huyện Cái Nước', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (970, 'Huyện Đầm Dơi', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (971, 'Huyện Năm Căn', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (972, 'Huyện Phú Tân', 'Huyện', 96);
INSERT INTO districts (district_id, district_name, district_type, city_id) VALUES (973, 'Huyện Ngọc Hiển', 'Huyện', 96);




INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (177, 67, '/storage/images_product/VwmBU4HPji_2_27db2b8209a642dca08dfe2ae2a5ebb1_master.webp', '2024-03-20 08:17:51', '2024-03-20 08:17:51');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (179, 65, '/storage/images_product/CVNfPCgWm3_2_7c2a9b61111b4864851b16e4d06f4edb_master.webp', '2024-03-20 08:44:19', '2024-03-20 08:44:19');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (180, 68, '/storage/images_product/bRHzFrNg4U_prada__48__e05659778fa14c158448290d033814d1_master.webp', '2024-03-20 09:45:07', '2024-03-20 09:45:07');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (181, 69, '/storage/images_product/LRGL4Ir93R_2_2e0e8ef5d34e4731ae1a24c44c021601_master.webp', '2024-03-20 09:49:49', '2024-03-20 09:49:49');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (182, 70, '/storage/images_product/lFPba3v6oA_12_180f140919bb4c50adae31226ae6b673_master.webp', '2024-03-20 15:24:49', '2024-03-20 15:24:49');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (183, 71, '/storage/images_product/Ku1hi9aE1q_2_4e7f571aea4a4f98bb44e39e56c375ea_master.webp', '2024-03-20 15:35:04', '2024-03-20 15:35:04');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (184, 72, '/storage/images_product/osxl7DBfMl_2_fb2cf89a40f0489e89ae2a4855840e47_master.webp', '2024-03-20 15:43:21', '2024-03-20 15:43:21');
INSERT INTO images (image_id, product_id, image_name, created_at, updated_at) VALUES (185, 73, '/storage/images_product/gprZnOJrdN_2_1836029c73f645e68a9d8ea868a868b4_master.webp', '2024-03-20 15:45:36', '2024-03-20 15:45:36');

INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (65, 'Kính Mát Unisex MOLSION MS3090 A16', 6, 3, '/storage/images_product/GUE2z8ysJ8_1_36f8927807b548ba89526758a9bfc5a0_master.webp', 2422000, 2322000, 13, 10, '<h2>M&Ocirc; TẢ SẢN PHẨM</h2>

<p>&nbsp;</p>

<h1><strong>Về thương hiệu&nbsp;MOLSION</strong></h1>

<p>&nbsp;</p>

<p>Molsion l&agrave; thương hiệu mắt k&iacute;nh nổi tiếng với phong c&aacute;ch thiết kế ấn tượng d&agrave;nh ri&ecirc;ng cho giới trẻ, v&agrave; hầu như c&aacute;c sản phẩm của Molsion đều lấy cảm hứng từ thiết kế, nghệ thuật v&agrave; văn h&oacute;a nhạc pop.</p>

<p>C&oacute; lẽ v&igrave; thế, d&ugrave; mang thương hiệu c&oacute; nguồn gốc từ nước Ph&aacute;p nhưng lại rất được ưa chuộng ở nhiều nước ở ch&acirc;u &Aacute;. Thật kh&ocirc;ng ngẫu nhi&ecirc;n m&agrave; Molsion đ&atilde; chọn người đại diện thương hiệu n&agrave;y bởi c&aacute;c ng&ocirc;i sao điện ảnh Hoa ngữ nổi tiếng như Dương Mịch, Huỳnh Hiểu Minh hay ng&ocirc;i sao H&agrave;n Quốc nổi tiếng Park Shin Hye.</p>

<p><img src="https://file.hstatic.net/200000689681/file/molsion_aa51d5a4477c48f9bb83edff5dfa77d8_grande.png" /></p>

<p>&nbsp;</p>

<p>Molsion thể hiện phương ch&acirc;m thuần t&uacute;y cho phong c&aacute;ch sản phẩm của m&igrave;nh &quot;Thời trang v&agrave; sự ph&aacute;t triển, biến h&oacute;a kh&ocirc;ng ngừng của xu hướng thời trang thế giới&rdquo;.</p>

<p>&nbsp;</p>

<h1><strong>Về&nbsp;K&iacute;nh M&aacute;t Unisex MOLSION MS3090&nbsp;A16</strong></h1>

<p><br />
<strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS3090&nbsp;A16&nbsp;</strong>được thiết kế tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung&nbsp;v&agrave; bắt kịp xu hướng,&nbsp;trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/4_80742c54de25430281730c93831feebb_grande.png" /></p>

<p>&nbsp;</p>

<p><strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS3090 A16</strong>&nbsp;được l&agrave;m từ chất liệu nhựa Acetate bền bỉ, nhẹ nh&agrave;ng. Thiết kế độc đ&aacute;o với LOGO&nbsp;thương hiệu nổi b&ecirc;n c&agrave;ng, trẻ trung, tạo n&ecirc;n phong c&aacute;ch cho người đeo v&agrave; ph&ugrave; hợp với nhiều d&aacute;ng khu&ocirc;n mặt.</p>', '<table border="0" cellpadding="0" cellspacing="0" style="width:100%">
	<tbody>
		<tr>
			<td style="width:50%">
			<h2>&nbsp;</h2>
			</td>
		</tr>
		<tr>
			<td>
			<h2><strong>TH&Ocirc;NG TIN CHI TIẾT&nbsp;</strong></h2>

			<p>&nbsp;</p>

			<table>
				<tbody>
					<tr>
						<td>
						<p><strong>KHUNG K&Iacute;NH</strong></p>

						<hr />
						<p>H&Igrave;NH DẠNG GỌNG: Vu&ocirc;ng&nbsp;</p>

						<p>M&Agrave;U GỌNG: Đen</p>

						<p>CHẤT LIỆU GỌNG: Nhựa Acetate</p>

						<p>M&Agrave;U TR&Ograve;NG: V&agrave;ng</p>
						</td>
						<td>
						<p>&nbsp;</p>

						<p>&nbsp;</p>

						<p>&nbsp;</p>

						<p>&nbsp;</p>
						</td>
					</tr>
				</tbody>
			</table>

			<table>
				<tbody>
					<tr>
						<td>
						<p>&nbsp;</p>

						<p><strong>K&Iacute;CH THƯỚC</strong></p>

						<hr />
						<p>ĐỘ RỘNG TR&Ograve;NG: 63&nbsp;mm&nbsp;</p>

						<p>CẦU K&Iacute;NH: 14&nbsp;mm</p>

						<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 148&nbsp;mm</p>
						</td>
						<td>
						<p>&nbsp;</p>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>', 'Kính Mát Unisex MOLSION MS3090 A16', 'Kính Mát Unisex MOLSION MS3090 A16', null);
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (67, 'Kính Mát Unisex MOLSION MS3096 C10', 6, 3, '/storage/images_product/PGFfya7gCW_3_66a02895ab274a088bca0915c6645a22_master.webp', 3002000, 2682000, 20, 5, '<h2>M&Ocirc; TẢ SẢN PHẨM</h2>

<p>&nbsp;</p>

<h1><strong>Về thương hiệu&nbsp;MOLSION</strong></h1>

<p>&nbsp;</p>

<p>Molsion l&agrave; thương hiệu mắt k&iacute;nh nổi tiếng với phong c&aacute;ch thiết kế ấn tượng d&agrave;nh ri&ecirc;ng cho giới trẻ, v&agrave; hầu như c&aacute;c sản phẩm của Molsion đều lấy cảm hứng từ thiết kế, nghệ thuật v&agrave; văn h&oacute;a nhạc pop.</p>

<p>C&oacute; lẽ v&igrave; thế, d&ugrave; mang thương hiệu c&oacute; nguồn gốc từ nước Ph&aacute;p nhưng lại rất được ưa chuộng ở nhiều nước ở ch&acirc;u &Aacute;. Thật kh&ocirc;ng ngẫu nhi&ecirc;n m&agrave; Molsion đ&atilde; chọn người đại diện thương hiệu n&agrave;y bởi c&aacute;c ng&ocirc;i sao điện ảnh Hoa ngữ nổi tiếng như Dương Mịch, Huỳnh Hiểu Minh hay ng&ocirc;i sao H&agrave;n Quốc nổi tiếng Park Shin Hye.</p>

<p><img src="https://file.hstatic.net/200000689681/file/molsion_aa51d5a4477c48f9bb83edff5dfa77d8_grande.png" /></p>

<p>Molsion thể hiện phương ch&acirc;m thuần t&uacute;y cho phong c&aacute;ch sản phẩm của m&igrave;nh &quot;Thời trang v&agrave; sự ph&aacute;t triển, biến h&oacute;a kh&ocirc;ng ngừng của xu hướng thời trang thế giới&rdquo;.</p>

<h1><strong>Về&nbsp;K&iacute;nh M&aacute;t Unisex MOLSION MS3096 C10</strong></h1>

<p><br />
<strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS3096 C10&nbsp;</strong>được thiết kế tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung&nbsp;v&agrave; bắt kịp xu hướng,&nbsp;trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p><img src="https://file.hstatic.net/200000689681/file/3_7030fb44a5bb4d0e80da665f8234d8cb_grande.png" /></p>

<p><strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS3096 C10</strong>&nbsp;được l&agrave;m từ chất liệu nhựa Acetate bền bỉ, nhẹ nh&agrave;ng. Thiết kế độc đ&aacute;o với t&ecirc;n thương hiệu nổi b&ecirc;n c&agrave;ng, trẻ trung, tạo n&ecirc;n phong c&aacute;ch cho người đeo v&agrave; ph&ugrave; hợp với nhiều d&aacute;ng khu&ocirc;n mặt.</p>

<p>&nbsp;
<p>&nbsp;</p>
</p>

<h2><strong>HƯỚNG DẪN BẢO QUẢN K&Iacute;NH</strong></h2>

<p>Bảo quản k&iacute;nh trong hộp khi kh&ocirc;ng sử dụng.</p>

<p>Kh&ocirc;ng chạm tay v&agrave;o tr&ograve;ng k&iacute;nh, kh&ocirc;ng đặt &uacute;p tr&ograve;ng k&iacute;nh xuống c&aacute;c bề mặt để tr&aacute;nh trầy xước.</p>

<p>D&ugrave;ng 2 tay cầm v&agrave;o 2 c&agrave;ng k&iacute;nh v&agrave; k&eacute;o thẳng khi đeo hoặc th&aacute;o k&iacute;nh để tr&aacute;nh biến dạng.</p>

<p>Thường xuy&ecirc;n vệ sinh k&iacute;nh bằng nước rửa k&iacute;nh v&agrave; khăn lau k&iacute;nh chuy&ecirc;n dụng.</p>', '<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Vu&ocirc;ng&nbsp;</p>

			<p>M&Agrave;U GỌNG: Đen</p>

			<p>CHẤT LIỆU GỌNG: Nhựa Acetate</p>

			<p>M&Agrave;U TR&Ograve;NG: Đen</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 62&nbsp;mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 17&nbsp;mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 148&nbsp;mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Kính Mát Unisex MOLSION MS3096 C10', 'Kính Mát Unisex MOLSION MS3096 C10', null);
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (68, 'Gọng Kính Unisex PRADA 0PR13XV_01G1O155.I', 6, 2, '/storage/images_product/Emr31FW297_prada__49__a2ad85d5aab04ea1a4d7c45f289edc9f_master.webp', 5884000, 5184000, 30, 20, '<h2>M&Ocirc; TẢ SẢN PHẨM</h2>

<p>&nbsp;</p>

<h2><strong>VỀ THƯƠNG HIỆU&nbsp;PRADA</strong></h2>

<p>&nbsp;</p>

<p>Prada thường tạo ra c&aacute;c ti&ecirc;u chuẩn về sắc đẹp để l&agrave;ng thời trang tu&acirc;n theo. Kể từ năm 1913, Prada đ&atilde; được gắn với phong c&aacute;ch ti&ecirc;n tiến. Thương hiệu k&iacute;nh Prada n&agrave;y c&oacute; một truyền thống mạnh mẽ về nghề thủ c&ocirc;ng kết hợp với tinh thần đổi mới, lu&ocirc;n nh&igrave;n về tương lai.&nbsp;C&aacute;c bộ sưu tập mắt k&iacute;nh của Prada c&oacute; chất lượng v&agrave; sự kh&eacute;o l&eacute;o vượt trội m&agrave; bạn mong đợi từ một thương hiệu nổi tiếng với bản sắc mạnh mẽ v&agrave; sự sang trọng kh&ocirc;ng thể phủ nhận được.&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/thiet_ke_chua_co_ten_-_2023-09-13t095817.938_ec1a012366a6405fb99f43baf1ea1eb5_grande.png" /></p>

<p>Mắt k&iacute;nh Prada gồm 2 nh&oacute;m phong c&aacute;ch thiết kế ch&iacute;nh l&agrave; hiện đại v&agrave; thể thao. Đối với nh&oacute;m hiện đại, phần thiết kế kh&ocirc;ng chỉ dựa tr&ecirc;n gi&aacute; trị truyền thống m&agrave; c&ograve;n xen lẫn c&aacute;c gi&aacute; trị l&agrave;m nổi bật kh&aacute;c biệt. Ri&ecirc;ng nh&oacute;m thể thao lại được thiết kế theo hơi hướng khỏe khoắn v&agrave; trẻ trung, chủ yếu d&agrave;nh cho nam giới. Bộ sưu tập&nbsp;<em>Prada Linea Rossa</em>, thuộc d&ograve;ng sản phẩm năng động v&agrave; giải tr&iacute;, được lấy cảm hứng từ thế giới thể thao. Prada đ&atilde; hợp t&aacute;c chặt chẽ với Đội đua thuyền buồm&nbsp;<em>Rossa&nbsp;</em>v&agrave; một số khu nghỉ dưỡng m&ugrave;a đ&ocirc;ng v&agrave; trường dạy trượt tuyết nổi tiếng nhất thế giới trong qu&aacute; tr&igrave;nh ph&aacute;t triển d&ograve;ng sản phẩm&nbsp; mang hơi hướng thể thao v&agrave; giải tr&iacute; của họ. Từ&nbsp;<em>&ldquo;Linea Rossa&rdquo;</em>&nbsp;bắt nguồn từ tiếng &Yacute; c&oacute; nghĩa l&agrave;&nbsp;<em>&ldquo;đường m&agrave;u đỏ&rdquo;</em>&nbsp;v&agrave; n&oacute; l&agrave; một yếu tố nổi bật tr&ecirc;n tất cả c&aacute;c loại k&iacute;nh phong c&aacute;ch thể thao của Prada.</p>

<p>&nbsp;</p>

<h2><strong>VỀ K&Iacute;NH GỌNG UNISEX&nbsp;PRADA 0PR13XV_01G1O155.I</strong></h2>

<p>&nbsp;</p>

<p><strong>K&iacute;nh Gọng&nbsp;Unisex 0PR13XV_01G1O155.I</strong>&nbsp;được thiết kế gọng chữ nhật tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung.&nbsp;<strong>K&iacute;nh Gọng&nbsp;Unisex PRADA 0PR13XV_01G1O155.I</strong>&nbsp;đ&atilde; trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang hiện nay.</p>

<p><img src="https://file.hstatic.net/200000689681/file/prada__48__20d55b4da8b2491e8736356366357f2d_grande.png" /></p>

<p><strong>K&iacute;nh Gọng&nbsp;Unisex PRADA 0PR13XV_01G1O155.I&nbsp;</strong>được l&agrave;m từ chất liệu nhựa chịu nhiệt&nbsp;cao cấp, bền bỉ. Thiết kế hiện đại, phong c&aacute;ch thời trang trẻ trung, năng động, dễ d&agrave;ng kết hợp với nhiều kiểu trang phục.&nbsp;</p>', '<h2><strong>TH&Ocirc;NG TIN CHI TIẾT</strong></h2>

<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Chữ nhật</p>

			<p>M&Agrave;U KHUNG: X&aacute;m trong</p>

			<p>CHẤT LIỆU GỌNG: Nhựa chịu nhiệt</p>

			<p>M&Agrave;U C&Agrave;NG K&Iacute;NH: X&aacute;m trong</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 55mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 18mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 145mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Gọng Kính Unisex PRADA 0PR13XV_01G1O155.I', 'Kính Gọng Unisex 0PR13XV_01G1O155.I được thiết kế gọng chữ nhật tinh tế tạo nên phong cách thời trang vô cùng trẻ trung. Kính Gọng Unisex PRADA 0PR13XV_01G1O155.I đã trở thành sự lựa chọn hàng đầu của nhiều tín đồ thời trang hiện nay.', null);
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (69, 'Gọng kính Unisex RAYBAN 0RX8769_112851.I', 6, 1, '/storage/images_product/TpsS8wKLh0_1_ef74be30c27a4e2584a44cf75f3b6f93_master.webp', 4564000, 4464000, 12, 20, '<h2>M&Ocirc; TẢ SẢN PHẨM</h2>

<p>&nbsp;</p>

<h2><strong>VỀ THƯƠNG HIỆU RAY-BAN</strong></h2>

<p>&nbsp;</p>

<p>Phong c&aacute;ch vượt thời gian, sống chất, v&agrave; tự do l&agrave; những gi&aacute; trị cốt l&otilde;i của Ray-Ban, một thương hiệu dẫn đầu trong cả k&iacute;nh m&aacute;t v&agrave; k&iacute;nh thường cho nhiều thế hệ người ti&ecirc;u d&ugrave;ng. Từ khi ra mắt mẫu k&iacute;nh đầy t&iacute;nh thương hiệu Aviator, d&agrave;nh ri&ecirc;ng cho những phi c&ocirc;ng Hoa Kỳ, Ray-Ban lu&ocirc;n dẫn đầu xu hướng trong việc thay đổi nhận thức văn ho&aacute;, v&agrave; đ&atilde; trở th&agrave;nh một biểu tượng của việc thể hiện chất ri&ecirc;ng, được tin y&ecirc;u bởi những người nổi tiếng v&agrave; c&oacute; sức ảnh hưởng khắp to&agrave;n cầu.</p>

<p>&nbsp;</p>

<p><img alt="PDP_banner_wayfarer_D" src="https://media.ray-ban.com/cms/resource/image/735172/landscape_ratio144x65/2592/1170/29d9353c65024861db7fd1e3ed405c66/83CBDF1FBB6EFAC17923A68A1A93BE09/pdp-banner-wayfarer-d.jpg" /></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<h2><strong>VỀ GỌNG K&Iacute;NH UNISEX&nbsp;RAYBAN 0RX8769_112851.I</strong></h2>

<p>&nbsp;</p>

<p><strong>Gọng k&iacute;nh Unisex RAYBAN 0RX8769_112851.I</strong>&nbsp;được thiết kế gọng vu&ocirc;ng tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung.&nbsp;<strong>Gọng k&iacute;nh Unisex RAYBAN 0RX8769_112851.I</strong>&nbsp;đ&atilde; trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p><img src="https://file.hstatic.net/200000689681/file/ray-ban_-_2023-10-12t100559.801_37a8114b3e364956ac1c4201123410f3_grande.png" /></p>

<p><strong>Gọng k&iacute;nh Unisex RAYBAN 0RX8769_112851.I</strong>&nbsp;được l&agrave;m từ chất liệu tintan cao cấp, bền bỉ. Thiết kế hiện đại, phong c&aacute;ch thời trang trẻ trung, năng động, dễ d&agrave;ng kết hợp với nhiều kiểu trang phục.&nbsp;</p>', '<h2><strong>TH&Ocirc;NG TIN CHI TIẾT</strong></h2>

<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Vu&ocirc;ng</p>

			<p>M&Agrave;U KHUNG: Đen</p>

			<p>CHẤT LIỆU GỌNG: Titanium</p>

			<p>M&Agrave;U C&Agrave;NG K&Iacute;NH: Đen</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 51mm</p>

			<p>CẦU K&Iacute;NH: 18mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 140mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Gọng kính Unisex RAYBAN 0RX8769_112851.I', 'Gọng kính Unisex RAYBAN 0RX8769_112851.I', 'Unisex');
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (70, 'Gọng Kính Nam BOLON BT1605 B91', 6, 4, '/storage/images_product/JsfGl3eskM_10_ac5d71deb4c848d895c6a7d578883d0a_master.webp', 4080000, 3980000, 20, 0, '<h2>M&Ocirc; TẢ SẢN PHẨM</h2>

<p>&nbsp;</p>

<h1><strong>Về Thương Hiệu BOLON</strong></h1>

<p>&nbsp;</p>

<p><strong>Bolon Eyewear</strong>&nbsp;l&agrave; thương hiệu k&iacute;nh mắt nổi tiếng thế giới của tập đo&agrave;n Essilor với phong c&aacute;ch tinh tế từ kinh đ&ocirc; thời trang Paris c&ugrave;ng chất liệu cao cấp v&agrave; kỹ thuật chế t&aacute;c k&iacute;nh tinh xảo của &Yacute;. Được ra đời từ những năm 1990, hiện nay, Bolon l&agrave; một trong những thương hiệu h&agrave;ng đầu thế giới với những mẫu k&iacute;nh thời trang mang phong c&aacute;ch thiết kế ch&acirc;u &Acirc;u c&oacute; cấu tạo đặc biệt d&agrave;nh ri&ecirc;ng cho người ch&acirc;u &Aacute;.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/store_810022010ebb4f1faf828d01cb03bdb2_grande.jpg" /></p>

<p>&nbsp;</p>

<p>Bolon được b&igrave;nh chọn l&agrave; TOP 5 thương hiệu b&aacute;n chạy nhất Ch&acirc;u &Aacute;. Thương hiệu n&agrave;y được ph&acirc;n phối tại c&aacute;c quốc gia được xem l&agrave; thi&ecirc;n đường mua sắm của thế giới: Th&aacute;i Lan, Singapore, Hồng K&ocirc;ng, Malaysia, H&agrave;n Quốc, &Yacute;, Ph&aacute;p&hellip;.</p>

<h1>&nbsp;</h1>

<h1><strong>Về&nbsp;Gọng K&iacute;nh Nam BOLON BT1605 B91</strong></h1>

<p>&nbsp;</p>

<p><strong>Gọng K&iacute;nh Nam BOLON BT1605 B91&nbsp;</strong>mang đến sự thanh lịch v&agrave; nh&atilde; nhặn với thiết kế tinh tế&nbsp;c&ugrave;ng chất liệu cao cấp. M&agrave;u sắc&nbsp;đầy tinh tế kh&ocirc;ng chỉ l&agrave;m nổi bật chiếc k&iacute;nh m&agrave; c&ograve;n tạo điểm nhấn cho vẻ ngoại h&igrave;nh hiện đại,&nbsp;sang trọng.</p>

<p>&nbsp;</p>

<p><img src="https://product.hstatic.net/200000689681/product/10_ac5d71deb4c848d895c6a7d578883d0a_large.png" /></p>

<p>&nbsp;</p>

<p>Với thiết kế đệm mũi tiện dụng, chiếc k&iacute;nh kh&ocirc;ng chỉ mang lại cảm gi&aacute;c thoải m&aacute;i m&agrave; c&ograve;n thể hiện sự chăm s&oacute;c đến từng chi tiết. Sự kết hợp tinh tế giữa kiểu d&aacute;ng hiện đại v&agrave; chất liệu&nbsp;chất lượng cao l&agrave;m cho&nbsp;<strong>Gọng K&iacute;nh Nam BOLON BT1605 B91&nbsp;</strong>trở th&agrave;nh biểu tượng của phong c&aacute;ch v&agrave; sự độc đ&aacute;o.</p>', '<h2><strong>TH&Ocirc;NG TIN CHI TIẾT&nbsp;</strong></h2>

<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Chữ nhật&nbsp;</p>

			<p>CHẤT LIỆU GỌNG: Kim loại</p>

			<p>M&Agrave;U GỌNG: Gun Metal</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 53 mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 18 mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 148 mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Gọng Kính Nam BOLON BT1605 B91', 'Gọng Kính Nam BOLON BT1605 B91', null);
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (71, 'Kính Mát Nữ MOLSION MS3101 C10', 6, 3, '/storage/images_product/r46a9jSTFs_1_ead3e6f2355c4ac4a06c2327e3935b6e_master.webp', 3082000, 2682000, 4, 10, '<h2>&nbsp;</h2>

<h1><strong>Về thương hiệu&nbsp;MOLSION</strong></h1>

<p>&nbsp;</p>

<p>Molsion l&agrave; thương hiệu mắt k&iacute;nh nổi tiếng với phong c&aacute;ch thiết kế ấn tượng d&agrave;nh ri&ecirc;ng cho giới trẻ, v&agrave; hầu như c&aacute;c sản phẩm của Molsion đều lấy cảm hứng từ thiết kế, nghệ thuật v&agrave; văn h&oacute;a nhạc pop.</p>

<p>C&oacute; lẽ v&igrave; thế, d&ugrave; mang thương hiệu c&oacute; nguồn gốc từ nước Ph&aacute;p nhưng lại rất được ưa chuộng ở nhiều nước ở ch&acirc;u &Aacute;. Thật kh&ocirc;ng ngẫu nhi&ecirc;n m&agrave; Molsion đ&atilde; chọn người đại diện thương hiệu n&agrave;y bởi c&aacute;c ng&ocirc;i sao điện ảnh Hoa ngữ nổi tiếng như Dương Mịch, Huỳnh Hiểu Minh hay ng&ocirc;i sao H&agrave;n Quốc nổi tiếng Park Shin Hye.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/molsion_aa51d5a4477c48f9bb83edff5dfa77d8_grande.png" /></p>

<p>&nbsp;</p>

<p>Molsion thể hiện phương ch&acirc;m thuần t&uacute;y cho phong c&aacute;ch sản phẩm của m&igrave;nh &quot;Thời trang v&agrave; sự ph&aacute;t triển, biến h&oacute;a kh&ocirc;ng ngừng của xu hướng thời trang thế giới&rdquo;.</p>

<p>&nbsp;</p>

<h1><strong>Về&nbsp;K&iacute;nh M&aacute;t Nữ&nbsp;MOLSION MS3101&nbsp;C10</strong></h1>

<p>&nbsp;</p>

<p><br />
<strong>K&iacute;nh M&aacute;t Nữ&nbsp;MOLSION MS3101&nbsp;C10&nbsp;</strong>được thiết kế tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung&nbsp;v&agrave; bắt kịp xu hướng,&nbsp;trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/1_4705a12c39a441c69c82a416d3e37647_grande.png" /></p>

<p><strong>K&iacute;nh M&aacute;t Nữ&nbsp;MOLSION MS3100 C10</strong>&nbsp;được l&agrave;m từ chất liệu nhựa Acetate&nbsp;cao cấp, bền bỉ. Thiết kế mắt m&egrave;o&nbsp;độc đ&aacute;o, trẻ trung, tạo n&ecirc;n phong c&aacute;ch cho người đeo v&agrave; ph&ugrave; hợp với nhiều d&aacute;ng khu&ocirc;n mặt.</p>', '<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Mắt M&egrave;o&nbsp;</p>

			<p>M&Agrave;U GỌNG: Đen</p>

			<p>CHẤT LIỆU GỌNG: Nhựa Acetate</p>

			<p>M&Agrave;U TR&Ograve;NG: Đen</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 54 mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 18&nbsp;mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 150 mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Kính Mát Nữ MOLSION MS3101 C10', 'Kính Mát Nữ MOLSION MS3101 C10', 'Nữ');
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (72, 'Kính Mát Unisex MOLSION MS5061 A10', 6, 3, '/storage/images_product/Kdm5zuw5eB_1_1af51ae2d7ae4a53b061d5ff51b1e71f_master.webp', 2622000, 2322000, 5, 10, '<h1><strong>Về thương hiệu&nbsp;MOLSION</strong></h1>

<p>&nbsp;</p>

<p>Molsion l&agrave; thương hiệu mắt k&iacute;nh nổi tiếng với phong c&aacute;ch thiết kế ấn tượng d&agrave;nh ri&ecirc;ng cho giới trẻ, v&agrave; hầu như c&aacute;c sản phẩm của Molsion đều lấy cảm hứng từ thiết kế, nghệ thuật v&agrave; văn h&oacute;a nhạc pop.</p>

<p>&nbsp;</p>

<p>C&oacute; lẽ v&igrave; thế, d&ugrave; mang thương hiệu c&oacute; nguồn gốc từ nước Ph&aacute;p nhưng lại rất được ưa chuộng ở nhiều nước ở ch&acirc;u &Aacute;. Thật kh&ocirc;ng ngẫu nhi&ecirc;n m&agrave; Molsion đ&atilde; chọn người đại diện thương hiệu n&agrave;y bởi c&aacute;c ng&ocirc;i sao điện ảnh Hoa ngữ nổi tiếng như Dương Mịch, Huỳnh Hiểu Minh hay ng&ocirc;i sao H&agrave;n Quốc nổi tiếng Park Shin Hye.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/molsion_aa51d5a4477c48f9bb83edff5dfa77d8_grande.png" /></p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>Molsion thể hiện phương ch&acirc;m thuần t&uacute;y cho phong c&aacute;ch sản phẩm của m&igrave;nh &quot;Thời trang v&agrave; sự ph&aacute;t triển, biến h&oacute;a kh&ocirc;ng ngừng của xu hướng thời trang thế giới&rdquo;.</p>

<p>&nbsp;</p>

<h1><strong>Về&nbsp;K&iacute;nh M&aacute;t Unisex MOLSION MS5061 A10</strong></h1>

<p>&nbsp;</p>

<p><br />
<strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS5061 A10&nbsp;</strong>được thiết kế tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung&nbsp;v&agrave; bắt kịp xu hướng,&nbsp;trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p><img src="https://file.hstatic.net/200000689681/file/1_a90746a943b3444c9434870598792bf3_grande.png" /></p>

<p><strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS5061 A10</strong>&nbsp;được l&agrave;m từ chất liệu nhựa Acetate bền bỉ, nhẹ nh&agrave;ng. Thiết kế độc đ&aacute;o với t&ecirc;n&nbsp;thương hiệu nổi b&ecirc;n c&agrave;ng, trẻ trung, tạo n&ecirc;n phong c&aacute;ch cho người đeo v&agrave; ph&ugrave; hợp với nhiều d&aacute;ng khu&ocirc;n mặt.</p>', '<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Mask&nbsp;</p>

			<p>M&Agrave;U GỌNG: Đen</p>

			<p>CHẤT LIỆU GỌNG: TR90</p>

			<p>M&Agrave;U TR&Ograve;NG: Đen</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 144&nbsp;mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 0&nbsp;mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 148&nbsp;mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Kính Mát Unisex MOLSION MS5061 A10', 'Kính Mát Unisex MOLSION MS5061 A10', 'Nam');
INSERT INTO products (product_id, product_name, category_id, brand_id, product_image, product_price_buy, product_price_sell, product_amount, product_sale, product_attribute, product_detail, product_keyword, product_description, product_gender) VALUES (73, 'Kính Mát Unisex MOLSION MS5061 A90', 6, 3, '/storage/images_product/PMOXiq5pEi_1_bc40abc4f4584989bef4cc584984634f_master.webp', 2822000, 2322000, 15, 10, '<h1><strong>Về thương hiệu&nbsp;MOLSION</strong></h1>

<p>&nbsp;</p>

<p>Molsion l&agrave; thương hiệu mắt k&iacute;nh nổi tiếng với phong c&aacute;ch thiết kế ấn tượng d&agrave;nh ri&ecirc;ng cho giới trẻ, v&agrave; hầu như c&aacute;c sản phẩm của Molsion đều lấy cảm hứng từ thiết kế, nghệ thuật v&agrave; văn h&oacute;a nhạc pop.</p>

<p>C&oacute; lẽ v&igrave; thế, d&ugrave; mang thương hiệu c&oacute; nguồn gốc từ nước Ph&aacute;p nhưng lại rất được ưa chuộng ở nhiều nước ở ch&acirc;u &Aacute;. Thật kh&ocirc;ng ngẫu nhi&ecirc;n m&agrave; Molsion đ&atilde; chọn người đại diện thương hiệu n&agrave;y bởi c&aacute;c ng&ocirc;i sao điện ảnh Hoa ngữ nổi tiếng như Dương Mịch, Huỳnh Hiểu Minh hay ng&ocirc;i sao H&agrave;n Quốc nổi tiếng Park Shin Hye.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/molsion_aa51d5a4477c48f9bb83edff5dfa77d8_grande.png" /></p>

<p>&nbsp;</p>

<p>Molsion thể hiện phương ch&acirc;m thuần t&uacute;y cho phong c&aacute;ch sản phẩm của m&igrave;nh &quot;Thời trang v&agrave; sự ph&aacute;t triển, biến h&oacute;a kh&ocirc;ng ngừng của xu hướng thời trang thế giới&rdquo;.</p>

<p>&nbsp;</p>

<h1><strong>Về&nbsp;K&iacute;nh M&aacute;t Unisex MOLSION MS5061 A90</strong></h1>

<p><br />
<strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS5061 A90&nbsp;</strong>được thiết kế tinh tế tạo n&ecirc;n phong c&aacute;ch thời trang v&ocirc; c&ugrave;ng trẻ trung&nbsp;v&agrave; bắt kịp xu hướng,&nbsp;trở th&agrave;nh sự lựa chọn h&agrave;ng đầu của nhiều t&iacute;n đồ thời trang.</p>

<p>&nbsp;</p>

<p><img src="https://file.hstatic.net/200000689681/file/1_2c2aa348f35f42fb916219da789ca723_grande.png" /></p>

<p><strong>K&iacute;nh M&aacute;t Unisex&nbsp;MOLSION MS5061 A90</strong>&nbsp;được l&agrave;m từ chất liệu nhựa Acetate bền bỉ, nhẹ nh&agrave;ng. Thiết kế độc đ&aacute;o với t&ecirc;n&nbsp;thương hiệu nổi b&ecirc;n c&agrave;ng, trẻ trung, tạo n&ecirc;n phong c&aacute;ch cho người đeo v&agrave; ph&ugrave; hợp với nhiều d&aacute;ng khu&ocirc;n mặt.</p>', '<table>
	<tbody>
		<tr>
			<td>
			<p><strong>KHUNG K&Iacute;NH</strong></p>

			<hr />
			<p>H&Igrave;NH DẠNG GỌNG: Mask&nbsp;</p>

			<p>M&Agrave;U GỌNG: Trắng</p>

			<p>CHẤT LIỆU GỌNG: TR90</p>

			<p>M&Agrave;U TR&Ograve;NG: Đen</p>
			</td>
			<td>
			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>

			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>

<table>
	<tbody>
		<tr>
			<td>
			<p>&nbsp;</p>

			<p><strong>K&Iacute;CH THƯỚC</strong></p>

			<hr />
			<p>ĐỘ RỘNG TR&Ograve;NG: 144&nbsp;mm&nbsp;</p>

			<p>CẦU K&Iacute;NH: 0&nbsp;mm</p>

			<p>CHIỀU D&Agrave;I C&Agrave;NG K&Iacute;NH: 148&nbsp;mm</p>
			</td>
			<td>
			<p>&nbsp;</p>
			</td>
		</tr>
	</tbody>
</table>', 'Kính Mát Unisex MOLSION MS5061 A90', 'Kính Mát Unisex MOLSION MS5061 A90', 'Nam');


INSERT INTO slide (id, slide_title, image, target, active, type, created_at, updated_at) VALUES (4, 'RAYBAN', '/storage/images_slide/ZBlwaufdUH_img_dk_item_home_slider_2_1.png', 'http://127.0.0.1:8000/shop/brand/1-rayban.html', 1, 1, '2023-11-04 23:16:49', '2024-03-25 18:09:05');
INSERT INTO slide (id, slide_title, image, target, active, type, created_at, updated_at) VALUES (5, 'Bolon', '/storage/images_slide/Il3GFUZ568_img_dk_item_home_slider_3_1.jpg', 'http://127.0.0.1:8000/shop/brand/4-bolon.html', 1, 1, '2024-03-20 07:40:01', '2024-03-25 18:08:14');



INSERT INTO users (user_id, user_name, user_email, password, user_phone, user_addres, user_district, user_city, provider, provider_id, role_id, created_at, updated_at, token) VALUES (26, 'Minh Hiếu', 'rongvang2357hn@gmail.com', '$2y$10$5OuvwlyX7s8Gx3SFJH04j.RRNsuStkKnvzlIXObCCMKHWINqe7LoO', '0856786728', 'Cần Thơ', 24, 2, 'google', '110848136296396830593', 2, '2023-11-07 10:24:20', '2024-03-30 06:45:40', null);
INSERT INTO users (user_id, user_name, user_email, password, user_phone, user_addres, user_district, user_city, provider, provider_id, role_id, created_at, updated_at, token) VALUES (27, 'a@bookshop.com', 'a@bookshop.com', '$2y$10$qZ5hsMI0maASjg4cFtahqey2vKqlYo7g/kjVdnfeOVPTMlF8WZQHO', null, null, null, null, null, null, 2, '2023-11-09 22:02:45', '2023-11-09 22:03:08', null);
INSERT INTO users (user_id, user_name, user_email, password, user_phone, user_addres, user_district, user_city, provider, provider_id, role_id, created_at, updated_at, token) VALUES (35, 'minhhieu', 'minhhieu@gmail.com', '$2y$10$IQRdnwloeR..lvAPwLyUPezPRSFfXVIG6dw3PNtY7r9DZMpiw2nzS', null, null, null, null, null, null, 1, '2024-03-30 06:34:37', '2024-03-30 06:35:38', null);


INSERT INTO coupons (coupon_id, coupon_name, coupon_code, coupon_value, coupon_status, coupon_expiry, user_id, created_at, updated_at) VALUES (2, 'backtoschool', 'student', 20, 1, '2024-03-31', null, '2024-03-30 06:26:32', '2024-03-30 06:27:17');